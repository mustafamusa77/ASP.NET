namespace WebApplication4.Models
{
    public class UserModel
    {
        public string? Name { get; set; }

        public int Age { get; set; }
    }
}