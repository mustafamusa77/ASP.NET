namespace WebApplication5.Models
{
    public class MonthModel
    {
        public int MonthNumber { get; set; }
        public string? MonthName { get; set; }
        public string? ErrorMessage { get; set; }
    }
}